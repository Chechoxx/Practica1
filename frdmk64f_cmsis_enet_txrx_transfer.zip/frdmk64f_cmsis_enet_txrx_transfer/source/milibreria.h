/*
 * milibreria.h
 *
 *  Created on: 16 sep. 2024
 *      Author: Usuario Final
 */

#ifndef MILIBRERIA_H_
#define MILIBRERIA_H_


void enet_init();
void ENET_SignalEvent_t(uint32_t event);
void send_msg(uint8_t *mensaje, uint8_t tam);

#endif /* MILIBRERIA_H_ */
