/*
 * Copyright 2017-2020 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/*  Standard C Included Files */
#include <string.h>
/*  SDK Included Files */
#include "Driver_ETH_MAC.h"
#include "pin_mux.h"
#include "board.h"
#include "fsl_debug_console.h"
#include "fsl_enet.h"
#include "fsl_enet_cmsis.h"
#include "fsl_enet_phy_cmsis.h"
#include "fsl_phy.h"
#include "stdlib.h"
#include "aes.h"

#include "fsl_common.h"
#include "fsl_sysmpu.h"
#include "fsl_phyksz8081.h"
#include "fsl_enet_mdio.h"
#include "RTE_Device.h"
#include "fsl_crc.h"

#include "milibreria.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/
/* ENET base address */
#define EXAMPLE_ENET     Driver_ETH_MAC0
#define EXAMPLE_ENET_PHY Driver_ETH_PHY0
#define ENET_DATA_LENGTH        (64)
#define ENET_EXAMPLE_LOOP_COUNT (1U)


#define ENET_RXBD_NUM (4)   // Number of receive buffers
#define ENET_TXBD_NUM (4)   // Number of transmit buffers
#define ENET_RXBUFF_SIZE (ENET_FRAME_MAX_FRAMELEN)  // Max frame length
enet_handle_t enetHandle;
enet_rx_bd_struct_t rxBuffDescrip[ENET_RXBD_NUM];   // Rx buffer descriptor array
enet_tx_bd_struct_t txBuffDescrip[ENET_TXBD_NUM];   // Tx buffer descriptor array

/* @TEST_ANCHOR*/

#ifndef MAC_ADDRESS
#define MAC_ADDRESS {0xd4, 0xbe, 0xd9, 0x45, 0x22, 0x61}
#endif

/*******************************************************************************
 * Prototypes
 ******************************************************************************/
// Buffers to hold the actual frame data
uint8_t rxDataBuff[ENET_RXBD_NUM][ENET_RXBUFF_SIZE];

// Function to initialize ENET peripheral
void enet_init() {
    enet_config_t config;
    enet_buffer_config_t buffConfig = {
        .rxBdNumber = ENET_RXBD_NUM,
        .txBdNumber = ENET_TXBD_NUM,
        .rxBuffSizeAlign = ENET_RXBUFF_SIZE,
        .txBuffSizeAlign = ENET_FRAME_MAX_FRAMELEN,
        .rxBdStartAddrAlign = rxBuffDescrip,
        .txBdStartAddrAlign = txBuffDescrip,
        .rxBufferAlign = rxDataBuff[0],
        .txBufferAlign = NULL,  // Only configuring for receiving
    };

    // Get the default configuration for ENET
    ENET_GetDefaultConfig(&config);

    // Initialize the ENET peripheral
    ENET_Init(ENET, &enetHandle, &config, &buffConfig, NULL, 120000000U);

    // Enable reception
    ENET_ActiveRead(ENET);
}
/*******************************************************************************
 * Variables
 ******************************************************************************/
//uint8_t g_frame[ENET_DATA_LENGTH + 14];
//volatile uint32_t g_testTxNum  = 0;
//uint8_t g_macAddr[6]           = MAC_ADDRESS;
//volatile uint32_t g_rxIndex    = 0;
//volatile uint32_t g_rxCheckIdx = 0;
//volatile uint32_t g_txCheckIdx = 0;
/*******************************************************************************
 * Code
 ******************************************************************************/
mdio_handle_t mdioHandle = {.ops = &enet_ops};
phy_handle_t phyHandle   = {.phyAddr = RTE_ENET_PHY_ADDRESS, .mdioHandle = &mdioHandle, .ops = &phyksz8081_ops};

uint32_t ENET0_GetFreq(void)
{
    return CLOCK_GetFreq(kCLOCK_CoreSysClk);
}

//void receive_ethernet_frame() {
//    status_t status;
//    enet_frame_info_t frameInfo;
//    uint8_t *data;
//    uint32_t length;
//
//    // Poll for a received frame
//    status = ENET_GetRxFrameSize(&enetHandle, &length, 0);
//
//    if (status == kStatus_Success && length > 0) {
//        // Allocate buffer to store the frame data
//        data = (uint8_t *)malloc(length);
//
//        // Read the received frame into the buffer
//        status = ENET_ReadFrame(ENET, &enetHandle, data, length, 0, &frameInfo);
//
//        if (status == kStatus_Success) {
//            // Process the received frame (e.g., print data or parse the frame)
//              	printf("Received Ethernet Frame, length: %lu\n", length);
//              	process_received_frame(data, length);
//
//            // Print out the first 16 bytes of the frame for debugging
//            for (uint32_t i = 0; i < 16 && i < length; i++) {
//                printf("%02X ", data[i]);
//            }
//            printf("\n");
//        } else {
//            printf("Failed to read the received frame\n");
//        }
//
//        // Free the allocated buffer
//        free(data);
//    } else if (status == kStatus_ENET_RxFrameEmpty) {
//        // No frame received
//        printf("No Ethernet frame available\n");
//    } else {
//        // Error in receiving the frame
//        printf("Error in receiving Ethernet frame\n");
//    }
//
//    PRINTF("Dato1 %X \r\n",data[14]);
//    PRINTF("Dato2 %X \r\n",data[15]);
//    PRINTF("Dato3 %X \r\n",data[16]);
//	PRINTF("Dato4 %X \r\n",data[17]);
//}


void process_received_frame(uint8_t *frame, uint32_t length) {
    if (length < 14) {
        printf("Invalid Ethernet frame\n");
        return;
    }

    // Display the Destination MAC address
    printf("Destination MAC: ");
    for (int i = 0; i < 6; i++) {
        printf("%02X ", frame[i]);
    }
    printf("\n");

    // Display the Source MAC address
    printf("Source MAC: ");
    for (int i = 6; i < 12; i++) {
        printf("%02X ", frame[i]);
    }
    printf("\n");

    // Display the EtherType
    uint16_t etherType = (frame[12] << 8) | frame[13];
    printf("EtherType: 0x%04X\n", etherType);

    // Display the payload (starting at byte 14)
    printf("Payload: ");
    for (uint32_t i = 14; i < length; i++) {
        printf("%02X ", frame[i]);
    }
    printf("\n");
}




/*!
 * @brief Main function
 */
int main(void)
{

	 /* Hardware Initialization. */
	    BOARD_InitPins();
	    BOARD_BootClockRUN();
	    BOARD_InitDebugConsole();

	    /* Disable SYSMPU. */
	    SYSMPU_Enable(SYSMPU, false);

	    mdioHandle.resource.base        = ENET;
	    mdioHandle.resource.csrClock_Hz = ENET0_GetFreq();


///8 Mensajes para enviar/////

	uint8_t mensaje1[]={0x48,0x4F,0x4C,0x41};
	uint8_t mensaje2[]={0x74,0x6F,0x6E,0x74,0x65,0x72,0xED,0x61};
	uint8_t mensaje3[]={0xAA,0xAA,0xAA,0xAA};
	uint8_t mensaje4[]={0xBB,0xBB,0xBB,0xBB};
	uint8_t mensaje5[]={0xCC,0xCC,0xCC,0xCC};
	uint8_t mensaje6[]={0xDD,0xDD,0xDD,0xDD};
	uint8_t mensaje7[]={0xEE,0xEE,0xEE,0xEE};
	uint8_t mensaje8[]={0xFF,0xFF,0xFF,0xFF};


	//uint8_t tam=0;
	uint8_t tam1=0;
	uint8_t tam2=0;
	uint8_t tam3=0;
	uint8_t tam4=0;
	uint8_t tam5=0;
	uint8_t tam6=0;
	uint8_t tam7=0;
	uint8_t tam8=0;


    //receive_ethernet_frame();
    PRINTF("\r\nENET example start.\r\n");


       	//tam_encrip=sizeof(padded_msg);

    /////////Mensaje1////////
    	tam1=sizeof(mensaje1);

       	send_msg(mensaje1,tam1);

       	////////Mensaje2////////
    	tam2=sizeof(mensaje2);

       	send_msg(mensaje2,tam2);

    	////////Mensaje3////////
        tam3=sizeof(mensaje3);

        send_msg(mensaje3,tam3);

    	////////Mensaje4////////
        	tam4=sizeof(mensaje4);

           	send_msg(mensaje4,tam4);


        	////////Mensaje5////////
            	tam5=sizeof(mensaje5);

               	send_msg(mensaje5,tam5);


            	////////Mensaje6////////
                	tam6=sizeof(mensaje6);

                   	send_msg(mensaje6,tam6);



                	////////Mensaje7////////
                    	tam7=sizeof(mensaje7);

                       	send_msg(mensaje7,tam7);



                    	////////Mensaje8////////
                        	tam8=sizeof(mensaje8);

                           	send_msg(mensaje8,tam8);




}

