///*
// * milibreria.c
// *
// *  Created on: 16 sep. 2024
// *      Author: Arcesio Arbelaez
// */
#include <string.h>
/*  SDK Included Files */
#include "Driver_ETH_MAC.h"
#include "pin_mux.h"
#include "board.h"
#include "fsl_debug_console.h"
#include "fsl_enet.h"
#include "fsl_enet_cmsis.h"
#include "fsl_enet_phy_cmsis.h"
#include "fsl_phy.h"
#include "stdlib.h"
#include "aes.h"

#include "fsl_common.h"
#include "fsl_sysmpu.h"
#include "fsl_phyksz8081.h"
#include "fsl_enet_mdio.h"
#include "RTE_Device.h"
#include "fsl_crc.h"


/* ENET base address */
#define EXAMPLE_ENET     Driver_ETH_MAC0
#define EXAMPLE_ENET_PHY Driver_ETH_PHY0
#define ENET_DATA_LENGTH        (64)
#define ENET_EXAMPLE_LOOP_COUNT (1U)


//#define ENET_RXBD_NUM (4)   // Number of receive buffers
//#define ENET_TXBD_NUM (4)   // Number of transmit buffers
//#define ENET_RXBUFF_SIZE (ENET_FRAME_MAX_FRAMELEN)  // Max frame length
//enet_handle_t enetHandle;
//enet_rx_bd_struct_t rxBuffDescrip[ENET_RXBD_NUM];   // Rx buffer descriptor array
//enet_tx_bd_struct_t txBuffDescrip[ENET_TXBD_NUM];   // Tx buffer descriptor array

/* @TEST_ANCHOR*/

#ifndef MAC_ADDRESS
#define MAC_ADDRESS {0xd4, 0xbe, 0xd9, 0x45, 0x22, 0x61}
#endif

/*******************************************************************************
 * Variables
 ******************************************************************************/
//uint8_t g_frame[ENET_DATA_LENGTH + 14];
volatile uint32_t g_testTxNum  = 0;
uint8_t g_macAddr[6]           = MAC_ADDRESS;
volatile uint32_t g_rxIndex    = 0;
volatile uint32_t g_rxCheckIdx = 0;
volatile uint32_t g_txCheckIdx = 0;
//******************************************************************************



void ENET_SignalEvent_t(uint32_t event)
{
    if (event == ARM_ETH_MAC_EVENT_RX_FRAME)
    {
        uint32_t size;
        uint32_t len;
        uint8_t dato1;
        uint8_t dato2;
        uint8_t dato3;
        uint8_t dato4;

        /* Get the Frame size */
        size = EXAMPLE_ENET.GetRxFrameSize();
        /* Call ENET_ReadFrame when there is a received frame. */
        if (size != 0)
        {
            /* Received valid frame. Deliver the rx buffer with the size equal to length. */
            uint8_t *data = (uint8_t *)malloc(size);
//            data[14]=0x00;
//            data[15]=0x00;
//            data[16]=0x00;
//            data[17]=0x00;


            if (data)
            {
                len = EXAMPLE_ENET.ReadFrame(data, size);
//                dato1=data[14];
//                dato2=data[15];
//                dato3=data[16];
//                dato4=data[17];
//                PRINTF("Paquete %X \r\n",dato1);
//                PRINTF("Paquete %X \r\n",dato2);
//                PRINTF("Paquete %X \r\n",dato3);
//                PRINTF("Paquete %X \r\n",dato4);


                //PRINTF("Paquete %c \r\n",data);
                if (size == len)
                {
                    /* Increase the received frame numbers. */
                    if (g_rxIndex < ENET_EXAMPLE_LOOP_COUNT)
                    {
                        g_rxIndex++;
                    }
                }

                //for (int i=1;i<=1;i++){

                //}
                free(data);
            }
        }
    }
    if (event == ARM_ETH_MAC_EVENT_TX_FRAME)
    {
        g_testTxNum++;
    }
}


void send_msg(uint8_t *mensaje, uint8_t tam)
{
	uint8_t g_frame[ENET_DATA_LENGTH + 14];
	uint32_t txnumber = 0;
	uint32_t count  = 0;
    uint32_t length = ENET_DATA_LENGTH - 14;
    ARM_ETH_LINK_INFO linkInfo;
    //PRINTF("basura inmunda %X \r\n",mensaje[14]);
    /* Initialize the ENET module. */
        EXAMPLE_ENET.Initialize(ENET_SignalEvent_t);
        EXAMPLE_ENET.PowerControl(ARM_POWER_FULL);
        EXAMPLE_ENET.SetMacAddress((ARM_ETH_MAC_ADDR *)g_macAddr);

        PRINTF("Wait for PHY init...\r\n");
        while (EXAMPLE_ENET_PHY.PowerControl(ARM_POWER_FULL) != ARM_DRIVER_OK)
        {
            PRINTF("PHY Auto-negotiation failed, please check the cable connection and link partner setting.\r\n");
        }

        EXAMPLE_ENET.Control(ARM_ETH_MAC_CONTROL_RX, 1);
        EXAMPLE_ENET.Control(ARM_ETH_MAC_CONTROL_TX, 1);
        PRINTF("Wait for PHY link up...\r\n");
        do
        {
            if (EXAMPLE_ENET_PHY.GetLinkState() == ARM_ETH_LINK_UP)
            {
                linkInfo = EXAMPLE_ENET_PHY.GetLinkInfo();
                EXAMPLE_ENET.Control(ARM_ETH_MAC_CONFIGURE, linkInfo.speed << ARM_ETH_MAC_SPEED_Pos |
                                                                linkInfo.duplex << ARM_ETH_MAC_DUPLEX_Pos |
                                                                ARM_ETH_MAC_ADDRESS_BROADCAST);
                break;
            }
        } while (1);

    #if defined(PHY_STABILITY_DELAY_US) && PHY_STABILITY_DELAY_US
        /* Wait a moment for PHY status to be stable. */
        SDK_DelayAtLeastUs(PHY_STABILITY_DELAY_US, SDK_DEVICE_MAXIMUM_CPU_CLOCK_FREQUENCY);
    #endif

   //uint8_t lon_men=0;
   //lon_men=sizeof(mensaje);
// Hasta aquí viene el código

 /* AES data */
           	    //Llave secreta
           	    uint8_t key[] = { 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06 };
           	    //Vector de inicializacion
           	    uint8_t iv[]  = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
           	    struct AES_ctx ctx;
           	    size_t test_string_len, padded_len;
           	    uint8_t padded_msg[512] = {0};
           	    /* CRC data */
           	    CRC_Type *base = CRC0;
           	    uint32_t checksum32;
           	    uint32_t seed;

           	    crc_config_t config;

           	              config.polynomial         = 0x04C11DB7U;
           	              config.seed               = seed;
           	              config.reflectIn          = true;
           	              config.reflectOut         = true;
           	              config.complementChecksum = true;
           	              config.crcBits            = kCrcBits32;
           	              config.crcResult          = kCrcFinalChecksum;

           	              CRC_Init(base, &config);



           	           	PRINTF("Prueba de encriptacion AES 128 con padding\r\n");

           	           	for(int j=0;j<tam;j++){
           	           	PRINTF("Mensaje sin encriptar: %X\r\n",mensaje[j]);
           	           	}

           	           	PRINTF("\nTesting AES128\r\n\n");
           	           	/* Init the AES context structure */
           	           	AES_init_ctx_iv(&ctx, key, iv);

           	           	/* El arreglo debe ser de un numero de elementos multiplo de 16, sino se agregan ceros hasta completar*/
           	           	test_string_len = strlen(mensaje);
           	           	padded_len = test_string_len + (16 - (test_string_len%16) );
           	           	memcpy(padded_msg, mensaje, test_string_len);

           	           	AES_CBC_encrypt_buffer(&ctx, padded_msg, padded_len);

           	           	PRINTF("Mensaje encriptado: ");
           	           	for(int i=0; i<padded_len; i++) {
           	           		PRINTF("0x%02x,", padded_msg[i]);
           	           	}
           	           	PRINTF("\r\n");
           	           	CRC_WriteData(CRC0, padded_msg, test_string_len);
           	           	uint32_t crcResult = CRC_Get32bitResult(CRC0);
           	           	PRINTF("Calculated CRC-32: 0x%X\n", crcResult);
           	           	PRINTF("tamano frame codificado %u \r\n",padded_len);

           	           	int* puntero_crc=crcResult;// Puntero que apunta al crcResult
           	           	uint8_t tam_crc=sizeof(crcResult);


           	           	//uint8_t *frametx[padded_len + tam_crc*4];
           	             PRINTF("CRC resultado32 \r\n");

          	          uint8_t byte0 = (uint8_t)(crcResult);         // Least significant byte
//           	          uint8_t byte1 = (uint8_t)(crcResult >> 8);    // Second byte
//           	          uint8_t byte2 = (uint8_t)(crcResult >> 16);   // Third byte
//           	          uint8_t byte3 = (uint8_t)(crcResult >> 24);   // Most significant byte


//
//           	           	PRINTF("Byte0: 0x%x\r\n", byte0);
//           	         PRINTF("Byte1: 0x%x\r\n", byte1);
//           	      PRINTF("Byte2: 0x%x\r\n", byte2);
//           	   PRINTF("Byte3: 0x%x\r\n", byte3);


// Mensaje con crc

    for (count = 0; count < ENET_DATA_LENGTH + 14 + 4; count++)
  {
        g_frame[count] = 0xFFU;

  }
    memcpy(&g_frame[6], &g_macAddr[0], 6U);
    g_frame[12] = (length >> 8) & 0xFFU;
    g_frame[13] = length & 0xFFU;

    for (count = 0; count < padded_len; count++)
    {
        //PRINTF("tamano mensaje %u",lon_men);
    	g_frame[count + 14] = padded_msg[count];
    	//g_frame[count + 14] = 0;
    	PRINTF("g_frame0 %X \r\n",padded_msg[count]);

    }


//         g_frame[padded_len + tam] = byte0;
//         g_frame[padded_len + tam+1] = byte1;
//         g_frame[padded_len + tam+2] = byte2;
//         g_frame[padded_len + tam+3] = byte3;
    		g_frame[14+padded_len] = crcResult;
            g_frame[14+padded_len+1] = crcResult >> 8;
            g_frame[14+padded_len+2] = crcResult >> 16;
            g_frame[14+padded_len+3] = crcResult >> 24;




    while (1)
        {
        	//receive_ethernet_frame();


            /* Check the total number of received number. */
            if (g_testTxNum && (g_txCheckIdx != g_testTxNum))
            {
                g_txCheckIdx = g_testTxNum;
                PRINTF("The %d frame transmitted success!\r\n", g_txCheckIdx);
            }
            if (g_rxCheckIdx != g_rxIndex)
            {
                g_rxCheckIdx = g_rxIndex;
                PRINTF("A total of %d frame(s) has been successfully received!\r\n", g_rxCheckIdx);
            }
            /* Get the Frame size */
            if (txnumber < ENET_EXAMPLE_LOOP_COUNT)
            {
                txnumber++;
                /* Send a multicast frame when the PHY is link up. */
                if (EXAMPLE_ENET.SendFrame(&g_frame[0], ENET_DATA_LENGTH, ARM_ETH_MAC_TX_FRAME_EVENT) == ARM_DRIVER_OK)
                {
                    SDK_DelayAtLeastUs(1000, SDK_DEVICE_MAXIMUM_CPU_CLOCK_FREQUENCY);
                    break;
                }
                else
                {
                    PRINTF(" \r\nTransmit frame failed!\r\n");
                }
            }
        }
        PRINTF(" \r\n Fin de transmision\r\n");
}


